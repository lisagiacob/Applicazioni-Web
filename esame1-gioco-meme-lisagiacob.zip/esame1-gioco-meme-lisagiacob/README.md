[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/J0Dv0VMM)
# Exam #1: "Gioco Meme"
## Student: s331407 Giacobazzi Lisa

## React Client Application Routes

- Route `/`: is the route that prints out the game rounds
- Route `/login`: is the route to do the log in, if the user is already logged, it is sent to `/`
- Route `/register`: page to register a new user
- Route `/game-summary`: page to visualize the summary of the game just played
- Route `/user-history`: page to visulize all the games (and rounds) ever played by the logged in user
- Route `*`: pageNotFound route, the requested route does not exist

## API Server

- GET `/api/sessions/current`
  - request parameters: no parameters
  - response body content: 
    - user: {id, username, password_hash, email, salt}
- POST `/api/sessions`
  - request parameters and request body content:
    - request body: user credentials
  - response body content: 
    - user: {id, username, password_hash, email, salt}
- POST `/api/register`
  - request parameters and request body content
    - request body: user credentials 
  - response body content: nothing
- DELETE `/api/sessions/current`
- GET `/api/start-game`
  - request parameters: no parameters
  - response body content: {meme, captions, rightCaptions} where meme: {id, iageUrl}, captions e rightCaptions: {id, text, correct}
- POST `/api/end-game`
  - request parameters and request body content:
    - request body: rounds: {meme, score, caption} where meme: {id, iageUrl}, captions: {it, text, correct}
    - response body content: nothing
- GET `/api/user-history`
  - request parameters: no parameters
  - response body content: games: {id, user_id, score played_at}
- GET `/api/game-rounds`
  - request parameters: gameId
  - response body content: rounds: {memeUrl, caption_text, correct, playedAt}

## Database Tables

- Table `users`:
  - id: INTEGER PRIMARY KEY
  - username: TEXT NOT NULL
  - password_hash: TEXT NOT NULL
  - email: TEXT NOT NULL
  - salt: TEXT NOT NULL
- Table `games`:
  - id: INTEGER PRIMARY KEY
  - user_id: INTEGER NOT NULL FOREIGN KEY
  - score: INTEGER DEFAULT 0
  - playedAt: DATETIME DEFAULT CURRENT
- Table `captions`:
  - id: INTEGER PRIMARY KEY
  - text: TEXT NOT NULL
- Table `memes`:
  - id: INTEGER PRIMARY KEY
  - image_name: TEXT NOT NULL
  - image_extension: TEXT NOT NULL
- Table `rounds`:
  - id: INTEGER PRIMARY KEY
  - game_id: INTEGER NOT NULL FOREIGN KEY
  - meme_id: INTEGER NOT NULL FOREIGN KEY
  - chosen_caption_id: INTEGER
  - correct: BOOLEAN NOT NULL
  - playedAt: DATETIME DEFAULT CURRENT
- Table `meme_caption`: {meme_id, caption_id} PRIMARY KEY
  - meme_id: INTEGER NOT NULL FOREIGN KEY 
  - caption_id: INTEGER NOT NULL FOREIGN KEY
  

## Main React Components

- `LoginForm` (in `AuthComponents.jsx`): Form to fill with the user credentials to log in
- `RegisterForm` (in `AuthComponents.jsx`): Form to fill with the user credentials to register
- `Games` (in `Games.jsx`): permits to visualize a meme game. Three rows made of one column: first one with the timer, second with the meme image, third with the captions to choose from.
- `GameSummary` (in `GameSummary.jsx`): shows the summary of the game just played
- `RoundComponent` (in `RoundComponent.jsx`): used in GameSummary and UserHistory to show the round cards
- `UserHistory` (in `UserHistory`): used to manage the visualization of the cronology of all the games played by the user.

## Screenshot

![Screenshot](./img/screenshot1.png)
![Screenshot](./img/screenshot2.png)

## Users Credentials

- user1, password 
- user2, password 
