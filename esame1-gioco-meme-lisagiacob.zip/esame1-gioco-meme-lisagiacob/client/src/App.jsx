import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import { Container, Row, Alert } from 'react-bootstrap';
import { Routes, Route, Outlet, Navigate } from 'react-router-dom';
import NavHeader from "./components/NavHeader";
import NotFound from './components/NotFoundComponent';
import { LoginForm, RegisterForm } from './components/AuthComponents';
import UserHistory from './components/UserHistory';
import Games from './components/Games';
import GamesSummary from './components/GamesSummary';
import API from './API.mjs';

function App() {
  const [loggedIn, setLoggedIn] = useState(false); 
  const [message, setMessage] = useState(''); 
  const [user, setUser] = useState(''); 

  const handleLogin = async (credentials) => {
    try {
      const user = await API.logIn(credentials);
      setLoggedIn(true);
      setMessage({msg: `Welcome, ${user.username}!`, type: 'success'});
      setUser(user);
    } catch (err) {
      setMessage({msg: err.message || 'Login failed', type: 'danger'});
      //window.location.href = 'http://localhost:5173'; // Redirect on login failure
    }
  };

  const handleRegister = async (credentials) => {
    try {
      await API.register(credentials);
      setMessage({ msg: 'Registration successful! Please log in.', type: 'success' });
    } catch (err) {
      setMessage({ msg: err.message || 'Registration failed', type: 'danger' });
    }
  };

  const handleLogout = async () => {
    await API.logOut();
    setLoggedIn(false);
    // clean up everything
    setMessage('');
  };

  return (
    <Routes>
      <Route element={
          <>
          <NavHeader loggedIn={loggedIn} handleLogout={handleLogout} user={user}/>
          <Container fluid className='mt-3'>
            {/* Sto creando un layeout con un contenitore che mostri un messaggio di alert
            sullo stato dell app, sotto il quale renderizza il contenuto della route corrente */}
            {message && <Row>
              <Alert variant={message.type} onClose={() => setMessage('')} dismissible>{message.msg}</Alert>
            </Row> }
            <Outlet/>
          </Container>
        </>
      }>
        <Route path='/login' element={
          // Se l'utente è loggato, reindirizziamo al gioco con Navigate <- replace per evitare di tornare indietro con il tasto back
          // altrimenti permettiamo il login mostrando il LoginForm
          loggedIn ? <Navigate replace to='/' /> : <LoginForm login={handleLogin} />
        }/>
        <Route path='/register' element={
          <RegisterForm register={handleRegister} />
        }/>
        <Route path='/' element={
          <Games loggedIn={loggedIn} setMessage={setMessage}/>
        }/>
        <Route path='/game-summary' element={
          <GamesSummary/>
        }/>
        <Route path='/user-history' element={
          loggedIn ? 
          <UserHistory/>
          : <Navigate replace to='/' />
        }/>
        <Route path="*" element={ 
          // *: Per qualsiasi percorso URL non catturato da altre rotte, mostriamo il componente NotFound
          <NotFound/> 
        }/>
      </Route>
    </Routes>
  );

}

export default App;
