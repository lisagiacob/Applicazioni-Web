import React, { useState, useEffect, useRef } from 'react';
import API from '../API.mjs';
import { useNavigate } from 'react-router-dom';
import { Row, Col, Container } from 'react-bootstrap';

function Games({ loggedIn, setMessage }) {
  const [rounds, setRounds] = useState([]);
  const [currentRound, setCurrentRound] = useState(1);
  const [meme, setMeme] = useState(null);
  const [captions, setCaptions] = useState([]);
  const navigate = useNavigate();
  const [usedMemes, setUsedMemes] = useState([]);
  const [rightCaptions, setRightCaps] = useState([]);
  const [timer, setTimer] = useState(30);
  const timerRef = useRef(null);

  useEffect(() => {
    const startGame = async () => {

      try {
        await fetchNewMemeAndCaptions();
      } catch (error) {
        console.error('Error starting game:', error);
      }
    };

    startGame();
  }, []); // Strict -> esecuzione

  useEffect(() => {
    if (timer === 0) {
      // Tempo scaduto -> passa al prossimo round
      const correctCaptionsText = rightCaptions.map(cap => cap.text).join(', ');
      setMessage({ msg: `Time Elapsed: failed to select a caption in 30 sec. Correct captions: ${correctCaptionsText}`, type: 'danger' });
      const cap = {id: null, text: "Time Elapsed: failed to select a caption in 30 sec", correct: false}
      playRound(meme, 0, cap);
    }
  }, [timer]);

  const resetTimer = () => {
    clearInterval(timerRef.current);
    setTimer(30);
    timerRef.current = setInterval(() => {
      setTimer(prev => prev - 1);
    }, 1000);
  };

  // Se non facessi il clear, rischierei di avere intervalli che si accavallano
  const clearTimer = () => {
    clearInterval(timerRef.current);
  };

  const fetchNewMemeAndCaptions = async () => {
    try {
      const { meme, captions, rightCaptions } = await API.getMemeACaption();
      if(usedMemes.includes(meme.id)) {
        return fetchNewMemeAndCaptions();
      }
      else{
        setMeme(meme);
        setCaptions(captions);
        setRightCaps(rightCaptions);
        setUsedMemes([...usedMemes, meme.id]);
        resetTimer();
      }
    } catch (error) {
      console.error('Error fetching meme and captions:', error);
    }
  };

  const playRound = async (meme, score, caption) => {
    clearTimer();
    if (currentRound > (loggedIn ? 3 : 1)) {
      return;
    }
    if(!caption.correct && caption.id !== null){
      const correctCaptionsText = rightCaptions.map(cap => cap.text).join(', ');
      setMessage({ msg: `Capion incorrect! Correct captions: ${correctCaptionsText}`, type: 'danger' });
    }
    else if(caption.id !== null) setMessage({ msg: `Good! Next Round!`, type: 'success' });
    try {
      // Risolvo così il problema dell'aggiornare lo stato in modo asincrono
      /**React pianifica l'aggiornamento dello stato e il componente verrà 
       * ri-renderizzato nel prossimo ciclo di rendering. */
      const newRounds = [...rounds, { meme, score, caption }];
      setRounds(newRounds);

      if (currentRound === (loggedIn ? 3 : 1)) {
        await endGame(newRounds);
      } else {
        setCurrentRound(currentRound + 1);
        await fetchNewMemeAndCaptions();
      }
    } catch (error) {
      console.error('Error playing round:', error);
    }
  };

  // Mod: Salvo partita e round qui <- vanno salvati solo alla fine del gioco!
  const endGame = async (finalRounds) => {
    try {
      if (loggedIn) {
        await API.endGame(finalRounds);
      }
      navigate('/game-summary', { state: { rounds: finalRounds} });
    } catch (error) {
      console.error('Error ending game:', error);
    }
  };

  return (
    <Container>
      <Row className="justify-content-center">
        <Col md={8} className="text-center">
          <h1>Time Left: {timer} seconds</h1>
          <p>Current Round: {currentRound}</p>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md={8} className="text-center">
          {meme && (
              <img src={meme.imageUrl} alt="Meme" className="img-fluid" 
              style={{ width: '100%', height: 'auto', maxWidth: '400px' }} />
          )} 
        </Col>
      </Row>
      <Row className="justify-content-center mt-4">
        <Col md={8} className="text-center">
          {meme && (
            <div>
              {captions.map(caption => (
                <button
                  type="button"
                  className="btn btn-outline-primary mb-2"
                  key={caption.id}
                  onClick={() => playRound(meme, caption.correct ? 5 : 0, caption)}
                >
                  {caption.text}
                </button>
              ))}
            </div>
          )}
        </Col>
      </Row>
    </Container>
  );
}

export default Games;
