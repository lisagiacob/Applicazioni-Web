import { Container, Navbar, Nav, Button, NavDropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { LogoutButton } from './AuthComponents';

function NavHeader({ loggedIn, handleLogout, user }) {
  return (
    <Navbar bg="primary" variant="dark">
      <Container>
        <Navbar.Brand as={Link} to="/">MemeGame</Navbar.Brand>
        {/* Nav server come contenitore per gli elementi di navigazione (es pulsanti)
          Lo stiamo usando per raggruppare i pulsanti di login, register e logout in base allo stato
          di autenticazione dell'utente */}
        <Nav className="ml-auto">
          { // Se l'utente è autenticato, mostriamo il pulsante di logout e il menu a tendina, 
            // altrimenti i pulsanti di login e register
            loggedIn ? (
              <>
                <NavDropdown title={user.username} id="user-dropdown">
                  <NavDropdown.Item as={Link} to="/user-history">User Page</NavDropdown.Item>
                  <NavDropdown.Item as={Link} to="/">New Game</NavDropdown.Item>
                </NavDropdown>
                <LogoutButton logout={handleLogout} />
              </>
          ) : (
            <>
              <Button as={Link} to="/login" variant="outline-light" className="mx-2">Login</Button>
              <Button as={Link} to="/register" variant="outline-light" className="mx-2">Register</Button>
            </>
          )}
        </Nav>
      </Container>
    </Navbar>
  );
}
export default NavHeader;
