import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, Button, Container, Row, Col } from 'react-bootstrap';
import RoundComponent from './RoundComponent';

function GamesSummary() {
  // L'hook useLocation restituisce la posizione corrente -> URL corrente.
  // L'oggetto restituito ha una proprietà state che contiene i dati passati tramite lo stato di navigazione.
  const { state } = useLocation();
  const { rounds } = state;
  // L'hook useNavigate restituisce una funzione di navigazione per navigare in un componente.
  // Potrò invocare navigate con un (percorso) per navigare in quel percorso.
  const navigate = useNavigate();

  // Calcola il punteggio totale
  const totalScore = rounds.reduce((acc, round) => acc + round.score, 0);

  // Filtra i round per includere solo quelli con punteggio positivo (ad esempio, corretti)
  const correctRounds = rounds.filter(round => round.caption.correct);
  return (
    <Container>
      <h1>Game Summary</h1>
      <p>Total Score: {totalScore}</p>
      <Row>
        {correctRounds.map((round, index) => (
          <RoundComponent key={round.id || index} round = {round}/>
        ))}
      </Row>
      <Button onClick={() => navigate('/')}>Start New Game</Button>
    </Container>
  );
}

export default GamesSummary;
