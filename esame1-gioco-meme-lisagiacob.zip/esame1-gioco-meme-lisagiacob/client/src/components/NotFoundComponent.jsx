export default function NotFound() {
    return(
        <p className="lead">Nothing to see here... This is not the route you are looking for!</p>
    );
}