import 'bootstrap-icons/font/bootstrap-icons.css';
import { useState } from 'react';
import { Row, Col, Table, Button, Card } from "react-bootstrap";
import { Link } from "react-router-dom";

function RoundComponent({ round, col}) {
	return(
		<>
			<Col md={4} className="mb-4">
				<Card style={{ width: '18rem', height: '100%', backgroundColor: col}}>
					{!round.score ?
					<Card.Header>
						<Card.Title>Round score: {round.correct ? 5 : 0}</Card.Title>
					</Card.Header> : null}
					<div style={{ width: '100%', height: '200px', overflow: 'hidden' }}>
						<Card.Img
							variant="top"
							src={round.meme ? round.meme.imageUrl : round.memeUrl}
							style={{ width: '100%', height: '100%', objectFit: 'cover' }}
						/>
					</div>
					<Card.Body>
						<Card.Text>{round.caption ? round.caption.text : round.caption_text}</Card.Text>
					</Card.Body>
				</Card>
			</Col>
		</>
	)
}

export default RoundComponent;