import React, { useState, useEffect } from 'react';
import API from '../API.mjs';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button } from 'react-bootstrap';
import RoundComponent from './RoundComponent';

function UserHistory() {
  const [games, setGames] = useState([]);
  const navigate = useNavigate();
  const [User, setUser] = useState({});

  const fetchUserHistory = async (userId) => {
    try {
      const gamesData = await API.getUserGames(userId);
      const gamesWithRounds = await Promise.all(
        gamesData.map(async (game) => {
          const roundsData = await API.getGameRounds(game.id);
          return { ...game, rounds: roundsData };
        })
      );
      setGames(gamesWithRounds);
    } catch (error) {
      console.error('Error fetching user history:', error);
    }
  };

  useEffect(() => {
    const start = async () => {
      const user = await API.getUserInfo();
      setUser(user);
      fetchUserHistory(user.id);
    };
    start();
  }, []);

  return (
    <Container>
      <h1> {User.username}'s User Page:</h1>
      <p>- Your email is: {User.email} -</p>
      <h2> Your Game History:</h2>
      <Row>
        {games.map((game, index) => (
          <Col md={12} key={index} className="mb-4">
            <h4>
              Game: {game.id}, Date: {new Date(game.playedAt).toLocaleString()}, Total Score: {game.score}
            </h4>
            <Row>
              {game.rounds.map((round, roundIndex) => (
                <RoundComponent round={round} key={roundIndex} col={round.correct ? "#28a745" : "#dc3545"}/>
              ))}
            </Row>
          </Col>
        ))}
      </Row>
      <Button onClick={() => navigate('/')} className="mb-4">
        Start New Game
      </Button>
    </Container>
  );
}

export default UserHistory;
