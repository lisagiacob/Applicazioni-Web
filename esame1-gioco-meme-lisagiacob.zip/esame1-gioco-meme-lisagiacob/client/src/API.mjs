//import {Question, Answer} from './QAModels.mjs';
const SERVER_URL = 'http://localhost:3001';

const getUserInfo = async () => {
	const response = await fetch(SERVER_URL + '/api/sessions/current', {
    method: 'GET',
	  credentials: 'include',
	});
	const user = await response.json();
	if (response.ok) {
	  return user;
	} else {
	  throw user;  // an object with the error coming from the server
	}
};

const logIn = async (credentials) => {
  const response = await fetch(SERVER_URL + '/api/sessions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'include',
    body: JSON.stringify(credentials),
  });
  if(response.ok) {
    const user = await response.json();
    return user;
  }
  else {
    const errDetails = await response.text();
    throw errDetails;
  }
};

const register = async (credentials) => {
	const response = await fetch(SERVER_URL + '/api/register', {
		method: 'POST',
		headers: {
		'Content-Type': 'application/json',
		},
		credentials: 'include',
		body: JSON.stringify(credentials),
	});
	if(response.ok) {
		return await response.json();
	} else {
		const errDetails = await response.text();
		throw new Error(errDetails);
	}
};

const logOut = async() => {
  const response = await fetch(SERVER_URL + '/api/sessions/current', {
    method: 'DELETE',
    credentials: 'include'
  });
  if (response.ok)
    return null;
}


const getMemeACaption = async () => {
  const response = await fetch(SERVER_URL + '/api/start-game', {
    method: 'GET',
    credentials: 'include',
  });
  if (response.ok) {
    return await response.json();
  } else {
    const errDetails = await response.text();
    throw new Error(errDetails);
  }
};

const endGame = async (rounds) => {
  const response = await fetch(SERVER_URL + '/api/end-game', {
    method: 'POST',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(rounds)
  });
  if (response.ok) {
    return;
  } else {
    const errDetails = await response.text();
    throw new Error(errDetails);
  }
};

const getUserGames = async (userId) => {
  const url = new URL(`${SERVER_URL}/api/user-history`);
  const response = await fetch(url.toString(), {
    method: 'GET',
    credentials: 'include',
  });
  if (!response.ok) {
    console.error('Network response was not ok:', response.statusText);
    throw new Error('Network response was not ok');
  }
  try {
    return await response.json();
  } catch (error) {
    throw error;
  }
};

const getGameRounds = async (gameId) => {
  const url = new URL(`${SERVER_URL}/api/game-rounds`);
  url.searchParams.append('gameId', gameId);
  const response = await fetch(url.toString(), {
    method: 'GET',
    credentials: 'include',
  });
  if (!response.ok) {
    console.error('Network response was not ok:', response.statusText);
    throw new Error('Network response was not ok');
  }
  try {
    return await response.json();
  } catch (error) {
    throw error;
  }
};

const API = { logIn, logOut, getUserInfo, register, endGame, getMemeACaption, getUserGames, getGameRounds };
export default API;