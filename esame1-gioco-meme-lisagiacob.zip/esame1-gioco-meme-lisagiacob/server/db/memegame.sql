-- Creare la tabella memes - caption1 e 2 sono i campi per le didascalie <- sempre 2, 2aN 
-- non faccio tabella a parte (molti a molti)
CREATE TABLE memes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_name TEXT NOT NULL,
    image_extension TEXT NOT NULL
);

-- Creare la tabella captions
CREATE TABLE captions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL
);

-- Tabella con le captions corrette per i meme
CREATE TABLE meme_caption (
    meme_id INTEGER,
    caption_id INTEGER,
    PRIMARY KEY (meme_id, caption_id),
    FOREIGN KEY (meme_id) REFERENCES memes (id) ON DELETE CASCADE,
    FOREIGN KEY (caption_id) REFERENCES captions (id) ON DELETE CASCADE
);

-- Creare la tabella users
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    salt TEXT NOT NULL
);

-- Creare la tabella games
CREATE TABLE games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    score INTEGER DEFAULT 0,
    played_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

-- Creare la tabella rounds
CREATE TABLE rounds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id INTEGER NOT NULL,
    meme_id INTEGER NOT NULL,
    chosen_caption_id INTEGER ,
    correct BOOLEAN NOT NULL,
    played_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (game_id) REFERENCES games (id) ON DELETE CASCADE,
    -- Se cancello un meme cancello anche i round associati altrimeti ho problemi di visualizzazione
    FOREIGN KEY (meme_id) REFERENCES memes (id) ON DELETE CASCADE, 
    FOREIGN KEY (chosen_caption_id) REFERENCES captions (id) ON DELETE CASCADE
);
