import sqlite from 'sqlite3';

// open the database
export const db = new sqlite.Database('db/memegame.sqlite', (err) => {
  if (err) throw err;
  else {
    db.get('SELECT * FROM users', (err, row) => {
      if (err) throw err;
    });
  }
});