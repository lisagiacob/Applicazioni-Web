import { db } from './db.mjs';
import bcrypt from 'bcrypt';
import dayjs from 'dayjs';

export const getUserByUsername = (username, password) => {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT * FROM users WHERE username = ?';
    db.get(sql, [username], (err, row) => {
      if (err) { 
        reject(err); 
      }
      else if (row === undefined) { 
        resolve(false); 
      }
      else { //user esiste già
        resolve(row)
      }
    });
  });
};

export const createUser = async (username, password, email) => {
  try {
    console.log(`Attempting to create user: ${username}`);
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const sql = 'INSERT INTO users (username, password_hash, email, salt) VALUES (?, ?, ?, ?)';
    return new Promise((resolve, reject) => {
      db.run(sql, [username, hashedPassword, email, salt], (err) => {
        if (err) {
          console.log(err);
          reject(err);
        } else {
          resolve({ username, email });
        }
      });
    });
  } catch (error) {
    console.error('Error creating User:', error);
    throw error;
  }
};

export const getRandomMeme = () => {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT * FROM memes ORDER BY RANDOM() LIMIT 1';
    db.get(sql, [], (err, row) => {
      if (err) {
        reject(err);
      } else {
        // Genera il percorso completo dell'immagine del meme
        const meme = {
          id: row.id,
          imageUrl: `http://localhost:3001/memes/${row.image_name}.${row.image_extension}`
        };
        resolve(meme);
      }
    });
  });
};

export const getCaptionsForMeme = (memeId) => {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT mc.caption_id as id, c.text as text, 1 as correct
      FROM meme_caption mc
      JOIN captions c ON mc.caption_id = c.id
      WHERE mc.meme_id = ?
      ORDER BY RANDOM() LIMIT 2`;
    db.all(sql, [memeId], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
};

export const getRandomCaptions = (captionId1, captionId2) => {
  return new Promise((resolve, reject) => {
    const sql = `
    SELECT id, text, 0 as correct
    FROM captions 
    WHERE id NOT IN (?, ?)
    ORDER BY RANDOM() LIMIT 5`;
    db.all(sql, [captionId1, captionId2], (err, rows) => {
      if (err || rows.length < 5) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
};

export const endGame = (rounds, user_id) => {
  return new Promise((resolve, reject) => {
    const sql = 'INSERT INTO games (user_id) VALUES (?)';
    db.run(sql, [user_id], function (err) {
      if (err) {
        reject(err);
      } else {
        const gameId = this.lastID;  // Capture lastID from the callback context
        
        const insertRound = (round) => {
          return new Promise((resolve, reject) => {
            const roundSql = 'INSERT INTO rounds (game_id, meme_id, correct, chosen_caption_id) VALUES (?, ?, ?, ?)';
            db.run(roundSql, [gameId, round.meme.id, round.caption.correct, round.caption.id], function (err) {
              if (err) {
                reject(err);
              } else {
                db.run('UPDATE games SET score = score + ? WHERE id = ?', [round.score, gameId], (err) => {
                  if (err) {
                    reject(err);
                  } else {
                    resolve();
                  }
                });
              }
            });
          });
        };

        const roundPromises = rounds.map(insertRound);
        
        Promise.all(roundPromises)
          .then(() => resolve())
          .catch(err => reject(err));
      }
    });
  });
};


export const getUserGames = (userId) => {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT * FROM games WHERE user_id = ? ORDER BY played_at DESC';
    db.all(sql, [userId], (err, rows) => {
      if (err) {
        reject(err);
      } else if (rows.length === 0) {
        resolve([]);
      } else {
        resolve(rows.map(row => ({
          id: row.id,
          score: row.score,
          playedAt: dayjs(row.played_at).toISOString(),
          userId: row.user_id,
          rounds: []
        })));
      }
    });
  });
};

export const getGameRounds = (gameId) => {
  return new Promise((resolve, reject) => {
    // COALESCE: ritorna il primo valore non nullo
    const sql = `
      SELECT M.image_name AS image_name, M.image_extension AS image_extension, 
             COALESCE(C.text, 'Time elapsed: no caption selected') AS caption_text, 
             R.correct AS correct, R.played_at AS played_at
      FROM rounds R
      JOIN memes M ON R.meme_id = M.id
      LEFT JOIN captions C ON R.chosen_caption_id = C.id
      WHERE R.game_id = ?
    `;
    db.all(sql, [gameId], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows.map(row => ({
          memeUrl: `http://localhost:3001/memes/${row.image_name}.${row.image_extension}`,
          caption_text: row.caption_text,
          correct: row.correct,
          playedAt: dayjs(row.played_at).toISOString()
        })));
      }
    });
  });
};