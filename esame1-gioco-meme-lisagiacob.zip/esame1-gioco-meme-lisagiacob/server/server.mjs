import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import morgan from 'morgan';
import cors from 'cors';
import bodyParser from 'body-parser';
import bcrypt from 'bcrypt';
import {getUserByUsername, createUser} from "./src/dao.mjs";
import {endGame} from "./src/dao.mjs";
import {getRandomMeme, getCaptionsForMeme, getRandomCaptions} from "./src/dao.mjs";
import { getUserGames, getGameRounds } from './src/dao.mjs';
import passport from 'passport';
import LocalStrategy from 'passport-local';
import session from 'express-session';

const app = express();
const port = 3001;

// middleware
app.use(express.json());
app.use(bodyParser.json());
app.use(morgan('dev'));

const corsOptions = {
  origin: 'http://localhost:5173',
  optionsSuccessStatus: 200,
  credentials: true
};
app.use(cors(corsOptions));


// IMMAGINI MEME
// Get directory corrente
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Configuro il esrver per i file statici
app.use('/memes', express.static(path.resolve(__dirname, 'db/memes')));
  
// Passport: set up local strategy
passport.use(new LocalStrategy(async function verify(username, password, done) {
  try {
    const user = await getUserByUsername(username);
    if (!user) {
      return done(null, false, { message: 'Incorrect username.' });
    }

    bcrypt.compare(password, user.password_hash, (err, result) => {
      if (err) {
        return done(err);
      }
      if (result) {
        return done(null, user);
      } else {
        return done(null, false, { message: 'Incorrect username or password.' });
      }
    });
  } catch (error) {
    return done(error);
  }
}));

passport.serializeUser(function (user, cb) {
  cb(null, user);
});
  
passport.deserializeUser(function (user, cb) { // user is: id + email + name
  return cb(null, user);
});
        
const isLoggedIn = (req, res, next) => {
  if(req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({error: 'Not authorized'});
}
            
app.use(session({
  secret: "shhhhh... it's a secret!",
  resave: false,
  saveUninitialized: false,
}));
app.use(passport.authenticate('session')); 


/* ROUTES */

app.post('/api/sessions', function(req, res, next) {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) {
      return res.status(401).send(info);
    }
    
    req.login(user, (err) => {
      if (err) return next(err);
      // req.user contains the authenticated user -> sensd all the user info back
      return res.status(201).json(req.user);
    });
  })(req, res, next);
});

app.post('/api/register', async (req, res) => {
  const { username, password, email } = req.body;

  try {
    console.log(`Attempting to register user: ${username}`);

    const existingUser = await getUserByUsername(username, password);
    if (existingUser) {
      console.log(`Username already exists: ${username}`);
      return res.status(400).json('Username already exists');
    }

    await createUser(username, password, email);
    console.log(`User created successfully: ${username}`);
    
    return res.status(201).json("User created successfully");
  } catch (err) {
    console.error(`Error creating User: ${err.message}`);
    return res.status(500).json('Error creating user: ' + err.message);
  }
});

// GET /api/sessions/current
// Uso la get per ottenere la sessione corrente e verificare se l'utente è autenticato
app.get('/api/sessions/current', (req, res) => {
  if(req.isAuthenticated()) {
    res.json(req.user);}
  else
    res.status(401).json({error: 'User not authenticated'});
});

// DELETE /api/sessions/current
// Uso la delete per fare il logout per indicare che la risora (sessione corrente) va eliminata
app.delete('/api/sessions/current', (req, res) => {
  req.logout(() => {
    res.end();
  });
});

// Rotta GET per ottenere meme e caption
app.get('/api/start-game', async (req, res) => {
  try {
    const meme = await getRandomMeme();
    const correctCaptions = await getCaptionsForMeme(meme.id);
    const correctCaptionIds = correctCaptions.map(caption => caption.id);
    const randomCaptions = await getRandomCaptions(correctCaptionIds[0], correctCaptionIds[1]);
    const allCaptions = [...correctCaptions, ...randomCaptions].sort(() => 0.5 - Math.random());

    res.json({
      meme,
      captions: allCaptions,
      rightCaptions: correctCaptions
    });
  } catch (error) {
    console.error('Error in /api/start-game:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/end-game', async (req, res) => {
  if (!req.isAuthenticated() ) {
    return res.status(201).json({ message: 'Game ended' });
  }
  const rounds = req.body;
  const userId = req.user.id;
  try {
    await endGame(rounds, userId);
    res.status(200).json({ message: 'Game ended'});
  } catch (err) {
    console.error('Error ending game:', err);
    res.status(500).json({ message: 'Error ending game' });
  }
});

app.get('/api/user-history', isLoggedIn, async (req, res) => {
  const userId = req.user.id;
  try {
    const games = await getUserGames(userId);
    res.json(games);
  } catch (error) {
    console.error('Error getting user history:', error);
    res.status(500).json({ message: 'Error getting user history' });
  }
});

app.get('/api/game-rounds', isLoggedIn, async (req, res) => {
  const gameId = req.query.gameId;
  try {
    const rounds = await getGameRounds(gameId);
    res.json(rounds);
  } catch (error) {
    console.error('Error getting game rounds:', error);
    res.status(500).json({ message: 'Error getting game rounds' });
  }
});
  
// far partire il server
app.listen(port, () => { console.log(`API server started at http://localhost:${port}`); });